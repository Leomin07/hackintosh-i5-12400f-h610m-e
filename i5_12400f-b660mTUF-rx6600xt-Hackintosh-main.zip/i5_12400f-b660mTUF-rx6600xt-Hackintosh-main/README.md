# i5_12400f-b660mTUF-rx6600xt-Hackintosh
 
